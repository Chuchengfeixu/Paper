CVX: A system for disciplined convex programming
Copyright 2012 Michael C. Grant and Stephen P. Boyd.
--------------------------------------------------------

Thank you for downloading cvx. Please see Appendix A of the
the users' guide, located in doc/cvx_usrguide.pdf, for information
on how to install this software.

Files of interest:
    COPYING.txt, GPL.txt: copyright information
    /cvx_usrguide.pdf:    documentation
    examples/:            usage examples

	

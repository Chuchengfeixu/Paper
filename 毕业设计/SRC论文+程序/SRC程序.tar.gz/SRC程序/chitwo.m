function ddist=chitwo(a,b)
ddist=sum(((a-b).^2)./(a+b));
end